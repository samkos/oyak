===================================
Platypus
===================================

.. rubric:: long flowing documents


doctemplate
-----------------------

.. automodule:: reportlab.platypus.doctemplate
   :members:


paragraph
-----------------------

.. automodule:: reportlab.platypus.paragraph
   :members:


paraparser
-----------------------

.. automodule:: reportlab.platypus.paraparser
   :members:


flowables
-----------------------

.. automodule:: reportlab.platypus.flowables
   :members:


frames
-----------------------

.. automodule:: reportlab.platypus.frames
   :members:


figures
-----------------------

.. automodule:: reportlab.platypus.figures
   :members:


tables
-----------------------

.. automodule:: reportlab.platypus.tables
   :members:


tableofcontents
-----------------------

.. automodule:: reportlab.platypus.tableofcontents
   :members:


xpreformatted
-----------------------

.. automodule:: reportlab.platypus.xpreformatted
   :members:


